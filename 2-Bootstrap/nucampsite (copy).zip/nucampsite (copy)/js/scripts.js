$(function() {
    $(".carousel").carousel( { interval: 2000 }); 
    $("#carouselButton").click(() => {
        if($("#carouselButton").children("i").hasClass("fa-pause")){ //if carousel is currently playing, pause carousel
            $(".carousel").carousel("pause"); 
            $("#carouselButton").children("i").removeClass("fa-pause"); 
            $("#carouselButton").children("i").addClass("fa-play");
        } else {
            $(".carousel").carousel("cycle");
            $("#carouselButton").children("i").removeClass("fa-play");
            $("#carouselButton").children("i").addClass("fa-pause");
        }
    });

    $("#reserveButton").click(function() {
        $("#reserveModal").modal('show');
        $(".close").click(function() {
            $("#reserveModal").modal('hide');
        });
    })

    $("#loginButton").click(function() {
        $("#loginModal").modal('show');
        $(".close").click(function() {
            $("#loginModal").modal('hide');
        });
    })    
});
